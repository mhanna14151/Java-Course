package Model;

import java.util.Objects;

/**
 * Represents a Model.Circle class, a Basic Model.Symbol, often used to construct Composite Symbols (e.g. a
 * Model.SnowPerson).
 */
public class Circle implements BasicSymbol {
  private Point2D origin;
  private double radius;

  /**
   * Constructs a Model.Circle, represented by an Origin and a radius.
   *
   * @param origin a Model.Point2D representing the center of the circle.
   * @param radius a double representing the distance extending outward from the origin.
   */
  public Circle(Point2D origin, double radius) {
    if (radius <= 0) {
      throw new IllegalArgumentException("Radius must be greater than zero");
    }
    this.origin = origin;
    this.radius = radius;

  }

  /**
   * Determines if two circles are 'touching', i.e. are within a certain threshold of one another.
   * The boundaries must overlap near a singular point, not merely intersect.
   *
   * @param other another circle.
   * @return true if they're touching, false otherwise.
   */
  protected boolean circlesTouching(Circle other) {
    double threshold = 2;
    double distanceOfRadii = radius + other.radius;
    return origin.euclidianDistance(other.origin) - distanceOfRadii < threshold;

  }

  /**
   * Check if three Circles's origins are within the same plane (origins could be connected
   * by a singular straight line) as one another.
   *
   * @param second another Model.Circle.
   * @param third  another Model.Circle.
   * @return true if they're in the same plane, false otherwise (threshold set within).
   */
  protected boolean circlesInLine(Circle second, Circle third) {
    double threshold = 2;
    double slopeBetweenThisAndSecond = slopeBetweenTwoCircleOrigins(second);
    double slopeBetweenThisAndThird = second.slopeBetweenTwoCircleOrigins(third);
    return Math.abs(slopeBetweenThisAndSecond - slopeBetweenThisAndThird) < threshold;

  }

  /**
   * Calculates the slope between two Circles. This is used as a helper function for circlesInLine.
   *
   * @param other another Model.Circle.
   * @return a double representing the slope between two Model.Circle's origins.
   */
  private double slopeBetweenTwoCircleOrigins(Circle other) {
    double y = origin.getY() - other.origin.getY();
    double x = origin.getX() - other.origin.getX();
    if (x == 0 && y != 0) {
      return Integer.MAX_VALUE;
    }
    return y / x;
  }

  /**
   * Gets the radius of the Model.Circle.
   *
   * @return the radius of the Model.Circle as a double.
   */
  public double getRadius() {
    double x = radius;
    return x;

  }

  /**
   * Returns the origin of this circle.
   * @return the origin of this circle.
   */
  public Point2D getOrigin() {
    Point2D resultOrigin;
    resultOrigin = new Point2D(this.origin.getX(), this.origin.getY());
    return resultOrigin;

  }

  /**
   * Used to determine if a Model.Circle and another Object are equal.
   *
   * @param other Ideally a Model.Circle, but any Object.
   * @return true if the two objects are equal, false otherwise.
   */
  @Override
  public boolean equals(Object other) {
    assert (other instanceof Circle);
    Circle something = (Circle) other;
    return (this.origin.equals(something.origin) && this.radius == something.radius);
  }


  @Override
  public String toString() {
    return "Circle{" +
            "Origin=" + getOrigin() +
            ", radius=" + getRadius() +
            '}';
  }

  /**
   * Redefines the hashCode function to reflect the change in the above equals method.
   *
   * @return an int representing the hash value.
   */
  @Override
  public int hashCode() {
    return Objects.hash(this.origin, this.radius);
  }

}
