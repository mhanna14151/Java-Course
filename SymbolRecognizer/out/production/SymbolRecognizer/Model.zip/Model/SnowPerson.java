package Model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Represents the Model.SnowPerson symbol. This is a Composite Model.Symbol constructed by the collection
 * of three Circles meeting the criteria of being connected and in a straight line.
 */
public class SnowPerson implements CompositeSymbol {
  private Circle oneCircle;
  private Circle secondCircle;
  private Circle thirdCircle;

  /**
   * Constructs a Model.SnowPerson out of three circles.
   *
   * @param oneCircle    a Model.Circle.
   * @param secondCircle a second Model.Circle.
   * @param thirdCircle  a third Model.Circle.
   */
  public SnowPerson(Circle oneCircle, Circle secondCircle, Circle thirdCircle) {
    if (!canMakeSnowPerson(oneCircle, secondCircle, thirdCircle)) {
      throw new IllegalArgumentException("This is not a valid Model.SnowPerson");
    }
    this.oneCircle = oneCircle;
    this.secondCircle = secondCircle;
    this.thirdCircle = thirdCircle;
  }

  public List<Circle> getCircles() {
    List<Circle> circles;
    circles = new ArrayList<>();
    circles.add(oneCircle);
    circles.add(secondCircle);
    circles.add(thirdCircle);
    return circles;
  }

  /**
   * Checks if each Model.Circle is touching one other circle, and if one of the Circles is touching two
   * Circles.
   */
  private static boolean threeTouchingCirclesCheck(Circle first, Circle second, Circle third) {
    if (first.circlesInLine(second, third)) {
      if (first.circlesTouching(second)) {
        return (first.circlesTouching(third) || second.circlesTouching(third));
      }
      if (first.circlesTouching(third)) {
        return (first.circlesTouching(second) || third.circlesTouching(second));
      }
    }
    return false;
  }

  /**
   * In a scenario of circles touching and are of the appropriate alignment, determines if the
   * sandwiched circle's size is less than one of the other circles, and greater than the other.
   *
   * @param first  a Model.Circle.
   * @param second a Model.Circle.
   * @param third  a Model.Circle.
   * @return true if the above conditions are met, false otherwise.
   */
  private static boolean sequentialSizeCheck(Circle first, Circle second, Circle third) {
    if (first.circlesInLine(second, third)) {
      if (first.circlesTouching(second) && first.circlesTouching(third)) {
        return (first.getRadius() > second.getRadius() && first.getRadius() < third.getRadius()) ||
                (first.getRadius() < second.getRadius() && first.getRadius() > third.getRadius());
      }
      if (second.circlesTouching(first) && second.circlesTouching(third)) {
        return (second.getRadius() > first.getRadius() && second.getRadius() < third.getRadius()) ||
                (second.getRadius() < first.getRadius() && second.getRadius() > third.getRadius());
      }
      if (third.circlesTouching(first) && third.circlesTouching(second)) {
        return (third.getRadius() > second.getRadius() && third.getRadius() < first.getRadius()) ||
                (third.getRadius() < second.getRadius() && third.getRadius() > first.getRadius());
      }
    }
    return false;
  }

  /**
   * Determines if all the conditions of a Model.SnowPerson are met for a set of three circles. -
   * Alignment - Two Circles touching only one other circle, one Model.Circle touching both those circles.
   * - Decreasing/Increasing in size (Middle circle in position is also the 'middle' circle in
   * size).
   *
   * @param first  a Model.Circle.
   * @param second another Model.Circle.
   * @param third  a third Model.Circle.
   * @return true if all the conditions are met, false otherwise.
   */
  public static boolean canMakeSnowPerson(Circle first, Circle second, Circle third) {
    return (threeTouchingCirclesCheck(first, second, third) &&
            sequentialSizeCheck(first, second, third));
  }

  /**
   * Used to determine if a Model.SnowPerson and another Model.SnowPerson are equal.
   *
   * @param other Ideally a Model.Point2D, but any Object.
   * @return true if the two objects are equal, false otherwise.
   */
  @Override
  public boolean equals(Object other) {
    assert (other instanceof SnowPerson);
    boolean isEqual = true;
    SnowPerson something = (SnowPerson) other;
    List<Circle> thisList = new ArrayList<>();
    List<Circle> otherList = new ArrayList<>();
    thisList.add(oneCircle);
    thisList.add(secondCircle);
    thisList.add(thirdCircle);
    otherList.add(something.oneCircle);
    otherList.add(something.secondCircle);
    otherList.add(something.thirdCircle);
    for (Circle circle : thisList) {
      if (!otherList.contains(circle)) {
        isEqual = false;
      }
    }
    return isEqual;
  }

  /**
   * Redefines the hashCode function to reflect the change in the above equals method.
   *
   * @return an int representing the hash value.
   */
  @Override
  public int hashCode() {
    return Objects.hash(this.oneCircle, this.secondCircle, this.thirdCircle);

  }

  /**
   * Creates a String representation of the SnowPerson.
   * @return a string representation of the SnowPerson.
   */
  @Override
  public String toString() {
    String str = "SnowPerson: with Circles: \n" +
            String.format("C1) Origin: (%d, %d) Radius: %d\n", (int) oneCircle.getOrigin().getX(),
                    (int) oneCircle.getOrigin().getY(), (int) oneCircle.getRadius())
            + String.format("C2) Origin: (%d, %d) Radius: %d\n", (int) secondCircle.getOrigin().getX(),
            (int) secondCircle.getOrigin().getY(), (int) secondCircle.getRadius())
            + String.format("C3) Origin: (%d, %d) Radius: %d\n", (int) thirdCircle.getOrigin().getX(),
            (int) thirdCircle.getOrigin().getY(), (int) thirdCircle.getRadius());
    return str;

  }


}