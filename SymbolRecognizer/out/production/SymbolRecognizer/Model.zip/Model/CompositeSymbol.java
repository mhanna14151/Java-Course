package Model;

/**
 * The Model.CompositeSymbol interface is used to logically provide a distinction between the two types of
 * Symbols used in the Model.SymbolsBank.
 */
public interface CompositeSymbol extends Symbol {
}
