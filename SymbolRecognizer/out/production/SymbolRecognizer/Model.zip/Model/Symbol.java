package Model;

/**
 * The Model.Symbol Interface is used to logically group all classes associated with such. As of now
 * this represents Model.Circle, Model.Line, Model.SnowPerson, and Model.Triangle.
 */
public interface Symbol {
}
