package Model;

/**
 * Represents an Equilateral Model.Triangle, which is a special case of a Model.Triangle, where all sides of the
 * triangle are equal.
 */
public class EquilateralTriangle extends Triangle {

  /**
   * The constructor for the equalateral triangle.  If the sides are not equal in length,
   * you cannot construct this.
   *
   * @param firstSide  the first side of the triangle.
   * @param secondSide the second side of the triangle.
   * @param thirdSide  the third side of the triangle.
   */
  public EquilateralTriangle(Line firstSide, Line secondSide, Line thirdSide) {
    super(firstSide, secondSide, thirdSide);
    double differenceOne = Math.abs(firstSide.getLength() - secondSide.getLength());
    double differenceTwo = Math.abs(secondSide.getLength() - thirdSide.getLength());
    double threshold = 2;
    if (differenceOne > threshold || differenceTwo > threshold) {
      throw new IllegalArgumentException("Sides must be equal");
    }
  }

  /**
   * Checks if the three lines are the same length or not.
   *
   * @param firstSide  a Model.Line.
   * @param secondSide a Model.Line.
   * @param thirdSide  a Model.Line.
   * @return true if they're all the same size (within a small threshold).
   */
  protected static boolean sidesEqual(Line firstSide, Line secondSide, Line thirdSide) {
    double differenceOne = Math.abs(firstSide.getLength() - secondSide.getLength());
    double differenceTwo = Math.abs(secondSide.getLength() - thirdSide.getLength());
    double threshold = 2;
    return (differenceOne < threshold && differenceTwo < threshold);
  }

  /**
   * Determines if one can make an equilateral triangle given three Lines.
   *
   * @param first  a Model.Line.
   * @param second a second Model.Line.
   * @param third  a third Model.Line.
   * @return true if the conditions for an equilateral triangle are met, false otherwise.
   */
  public static boolean canMakeEquilateralTriangle(Line first, Line second, Line third) {
    if (sidesEqual(first, second, third)) {
      return canMakeTriangle(first, second, third);
    }
    return false;
  }
}
