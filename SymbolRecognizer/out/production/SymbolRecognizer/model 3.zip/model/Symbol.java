package model;

/**
 * The model.Symbol Interface is used to logically group all classes associated with such. As of now
 * this represents model.Circle, model.Line, model.SnowPerson, and model.Triangle.
 */
public interface Symbol {
}
