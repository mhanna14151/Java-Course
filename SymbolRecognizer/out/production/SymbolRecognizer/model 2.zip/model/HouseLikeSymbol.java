package model;

/**
 * Created by hannam on 4/24/17.
 */
public class HouseLikeSymbol {


  /**
   * Calculates if the center of a triangle is within a rectangle or not
   */
  public boolean withinRectangleHuh() {
    // Get the upper and lower bounds of X
    // Get the upper and lower bounds of Y
    // Get the Center of the Triangle Xt Yt

    int xMax = 0;
    int xMin = 0;
    int yMin = 0;
    int yMax = 0;
    int xT = 1;
    int yT = 1;


    if ((xMin < xT && xT < xMax) && (yMin < yT && yT < yMax)) {
      return true;

    }

    return true;
  }

}
