package model;

/**
 * Created by hannam on 4/24/17.
 */
public class Cassette {
  private Circle firstCircle;
  private Circle secondCircle;
  private Line onlyLine;
  private Rectangle onlyRectangle;


}
